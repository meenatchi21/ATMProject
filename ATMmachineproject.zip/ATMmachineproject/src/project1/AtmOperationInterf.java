package project1;

public interface AtmOperationInterf {
	public void ViewBalance();
	public void withdrawAmount(double withdrawAmount);
	public void depositAmount(double depositAmount);
	public void viewMiniStatement();
}
